# default configuration
yum_globalconfig '/tmp/yum.conf' do
  action :create
end
