default["monit"]["postgres"]["pid_file"] = '/var/run/postgresql/9.1-main.pid'
default["monit"]["postgres"]["unix_socket_path"] = '/var/run/postgresql/.s.PGSQL'
default["monit"]["postgres"]["port"] = 5432
