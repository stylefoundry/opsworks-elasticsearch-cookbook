default["monit"]["unicorn"]["pid_dir"] = '/path/to/pids'
default["monit"]["unicorn"]["worker_count"] = 1
