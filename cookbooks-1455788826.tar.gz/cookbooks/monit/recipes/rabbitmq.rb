include_recipe "monit"

monitrc "rabbitmq"
