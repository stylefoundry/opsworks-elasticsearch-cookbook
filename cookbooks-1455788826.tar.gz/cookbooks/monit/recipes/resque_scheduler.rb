include_recipe "monit"

monitrc "resque_scheduler"
