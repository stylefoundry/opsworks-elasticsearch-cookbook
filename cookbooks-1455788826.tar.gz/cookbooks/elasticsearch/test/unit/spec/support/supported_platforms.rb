def supported_platforms
  {
    'ubuntu' => ['12.04', '14.04'],
    'centos' => ['6.5']
  }
end
