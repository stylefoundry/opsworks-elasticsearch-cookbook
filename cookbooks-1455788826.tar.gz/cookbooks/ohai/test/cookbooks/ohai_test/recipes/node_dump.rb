file '/tmp/node.json' do
  content JSON.pretty_generate(node)
end
