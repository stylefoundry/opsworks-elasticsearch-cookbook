ohai_hint 'test' do
  content Hash[:a, 'hogehoge']
end
