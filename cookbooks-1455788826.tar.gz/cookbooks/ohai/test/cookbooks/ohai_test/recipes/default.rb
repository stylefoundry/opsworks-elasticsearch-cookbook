#
# Cookbook Name:: ohai_test
# Recipe:: default
#
# Copyright 2013, HiganWorks LLC.
#
