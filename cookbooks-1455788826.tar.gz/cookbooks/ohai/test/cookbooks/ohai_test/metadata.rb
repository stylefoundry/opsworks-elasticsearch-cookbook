name             'ohai_test'
maintainer       'HiganWorks LLC.'
maintainer_email 'sawanoboriyu@higanworks.com'
license          ''
description      'Installs/Configures ohai_test'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
depends          'ohai'
