Contributing
------------
1. Fork the repo
2. Create a topic branch
3. Make your changes (and write specs! see [ChefSpec](https://github.com/acrmp/chefspec))
  * Run specs with `bundle exec rspec`
4. Submit a pull request
